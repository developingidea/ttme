# v2.1.1
## 11/19/2015

1. [](#bugfix)
    * Pagination compatibility

# v2.1.0
## 10/15/2015

1. [](#new)
    * Removed SimpleForm plugin support due to constant compatibility problems
    * Added support for Email and Form plugins

# v2.0.0
## 09/21/2015

1. [](#improved)
    * Reworked codebase for better compatibility and css handling
    * Lots of fixes

# v1.2.0
## 09/21/2015

1. [](#improved)
    * Improved compatibility with newest Grav
    * Improved compatibility with SimpleForm component
    * Minor fixes

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.0
## 06/16/2015

1. [](#new)
    * ChangeLog started...
