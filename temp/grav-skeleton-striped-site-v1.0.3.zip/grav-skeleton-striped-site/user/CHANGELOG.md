# v1.0.3
## 10/15/2015

1. [](#new)
    * Removed SimpleForm plugin support due to constant compatibility problems
    * Added support for Email and Form plugins

# v1.0.2
## 09/21/2015

1. [](#new)
    * theme updates

# v1.0.1
## 09/21/2015

1. [](#new)
    * Added landing page for SimpleForm

# v1.0.0
## 06/16/2015

1. [](#new)
    * ChangeLog started...
