# v1.1.0
## 01/20/2016

1. [](#new)
    * Basic Multi-Language support
2. [](#bugfix)
    * Minor bugfixes for navigation

# v1.0.0
## 01/18/2016

1. [](#new)
    * ChangeLog started...
