<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Receptar extends Theme
{

}
