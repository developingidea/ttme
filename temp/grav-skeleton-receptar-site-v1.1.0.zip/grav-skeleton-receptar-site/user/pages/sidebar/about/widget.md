---
title: About
taxonomy:
    category: sidebar
css_suffix: widget_text
---

Receptar is simple, modern, responsive, high-DPI, fully customizable blog Grav theme. It features split-screen book-like design inspired by a modern cook book with emphasize on beautiful imagery and typography.

More info at [getgrav.org](getgrav.org).
