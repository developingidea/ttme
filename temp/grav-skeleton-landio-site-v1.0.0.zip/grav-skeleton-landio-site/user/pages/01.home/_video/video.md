---
hidemenu: true
title: Videos
videos:
  - poster: video-poster.jpg
    sources:
      - url: http://vjs.zencdn.net/v/oceans.mp4
        type: video/mp4
      - url: http://vjs.zencdn.net/v/oceans.webm
        type: video/webm

---

### Video {.sr-only}
