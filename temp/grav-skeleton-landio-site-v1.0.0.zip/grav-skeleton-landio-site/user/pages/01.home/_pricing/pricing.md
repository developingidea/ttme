---
title: Subscriptions
pricing:
  - title: Personal
    description: Sed risus feugiat fusce eu sit conubia venenatis aliquet nisl cras.
    currency: $
    price: 19
    period: /month
    features:
      - item: Sed risus feugiat
      - item: Sed risus feugiat fusce eu sit
      - item: Sed risus feugiat fusce
    button_url: "#"
    button_text: Get Started
    highlighted: false
    additional_css: wp-5
  - title: Professional
    description: Sed risus feugiat fusce eu sit conubia venenatis aliquet nisl cras.
    currency: $
    price: 49
    period: /month
    features:
      - item: Sed risus feugiat
      - item: Sed risus feugiat fusce eu sit
      - item: Sed risus feugiat fusce
      - item: Sed risus feugiat
    button_url: "#"
    button_text: Get Started
    highlighted: true  
  - title: Enterprise
    description: Sed risus feugiat fusce eu sit conubia venenatis aliquet nisl cras.
    currency: $
    price: 99
    period: /month
    features:
      - item: Sed risus feugiat
      - item: Sed risus feugiat fusce eu sit
      - item: Sed risus feugiat fusce
    button_url: "#"
    button_text: Get Started
    highlighted: false
    additional_css: wp-6

---
### Manage your subscriptions
